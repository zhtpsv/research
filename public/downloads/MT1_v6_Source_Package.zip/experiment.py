"""MT1 revision: matched braking ablations and negative-control scenarios.
base_model.py contains retained MT1 sampling and exact kinematics helpers.
This script is independent of the previous output directory.
"""
from pathlib import Path
import csv,json,platform,hashlib
import numpy as np
from base_model import sample,network,advance,wilson
ROOT=Path(__file__).resolve().parent
SEED=20261018
THRESHOLDS=[50,100,150,200,250,400]
PROFILES=['P0','P1','P2','P3']

def nominal(g,v,vl,limit=3):
    return np.clip(.7*(g-(3+1.2*v))+.9*(vl-v),-limit,1.5)

def simulate(c,trace,threshold=None,fallback='stop',force=3,local=False,nominal_limit=3,
             scenario='brake',phase=None,dt=.01,local_tick=.01,inclusive=False,recovery=3):
    n=len(c['v']);ticks=round(10/dt);period=round(.05/dt);decision=round(local_tick/dt)
    phase=np.zeros(n,dtype=int) if phase is None else np.rint(phase/dt).astype(int)
    xe=np.zeros(n);xl=c['gap'].copy();ve=c['v'].copy();vl=ve.copy()
    cmd=np.zeros(n);stamp=np.zeros(n);mode=np.zeros(n,bool);fresh=np.zeros(n,int);a=np.zeros(n)
    alive=np.ones(n,bool);coll=np.zeros(n);near=np.zeros(n);fb=np.zeros(n);blocked=np.zeros(n)
    impact=np.zeros(n);entries=np.zeros(n);pending={};delays,loss=trace
    onset=np.ceil(c['onset']/.01-1e-9)*.01
    for k in range(ticks):
        t=k*dt;gap=xl-xe
        gen=np.flatnonzero(k%period==phase)
        if len(gen):
            j=k//period;values=nominal(gap[gen],ve[gen],vl[gen],nominal_limit)
            at=k+np.ceil(delays[gen,j]/dt-1e-9).astype(int);valid=~loss[gen,j]
            for due in np.unique(at[valid]):
                sub=(at==due)&valid;ii=gen[sub]
                pending.setdefault(int(due),[]).append((ii,values[sub].copy(),t))
        for ii,values,s in pending.pop(k,[]):
            jj=ii[s>=stamp[ii]];cmd[jj]=values[s>=stamp[ii]];stamp[jj]=s
        if k%decision==0:
            old=mode.copy();age=(t-stamp)*1000
            if local:mode[:]=False;a=nominal(gap,ve,vl,nominal_limit)
            elif threshold is None:mode[:]=False;a=cmd.copy()
            else:
                stale=age>=threshold-1e-7 if inclusive else age>threshold+1e-7
                mode|=stale
                if k%period==0:
                    fresh=np.where(mode & ~stale,fresh+1,0)
                    mode &= fresh<recovery
                    fresh=np.where(mode,fresh,0)
                fresh=np.where(stale,0,fresh)
                backup=nominal(gap,ve,vl,nominal_limit) if fallback=='local' else np.full(n,-force)
                a=np.where(mode,backup,cmd)
            entries+=mode & ~old & alive
        fb+=mode*alive*dt
        blocked+=(alive & (ve<.1) & (vl>.1))*dt
        closing=ve-vl
        near+=(alive & (closing>1e-9)&(gap/np.maximum(closing,1e-9)<1.5))*dt
        la=np.where(t+1e-9>=onset,-c['brake'],0.) if scenario=='brake' else np.zeros(n)
        nx,nv=advance(xe,ve,a,dt);nl,nlv=advance(xl,vl,la,dt)
        contact=alive & ((nl-nx)<=0)
        impact[contact]=np.maximum(0,nv[contact]-nlv[contact])
        xe=np.where(alive,nx,xe);ve=np.where(alive,nv,0)
        xl=np.where(alive,nl,xl);vl=np.where(alive,nlv,0)
        coll[contact]=1;alive[contact]=False
    return dict(collision=coll,near_s=near,distance_m=xe,fallback_s=fb,
                stopped_while_lead_moves_s=blocked,impact_mps=impact,impact_squared=impact**2,entries=entries)

def csvout(name,rows):
    with (ROOT/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def run():
    c=sample(400,SEED);net=network(400,SEED+1)
    phase=np.random.default_rng(SEED+3).integers(0,5,400)*.01
    csvout('cases.csv',[dict(case=i,phase_s=float(phase[i]),**{k:float(v[i]) for k,v in c.items()}) for i in range(400)])
    np.savez_compressed(ROOT/'network_traces.npz',**{f'{p}_{kind}':x for p in PROFILES for kind,x in zip(['delay','loss'],net[p])})
    rows=[];summary=[];raw={};count=0
    def evaluate(p,sc,label,**kwargs):
        nonlocal count
        key=(p,sc,label)
        if key in raw:return
        r=simulate(c,net[p],scenario=sc,phase=phase,**kwargs);raw[key]=r;count+=400
        assert all(np.isfinite(v).all() for v in r.values())
        for i in range(400):rows.append(dict(case=i,profile=p,scenario=sc,config=label,**{k:float(v[i]) for k,v in r.items()}))
        ncoll=int(r['collision'].sum())
        summary.append(dict(profile=p,scenario=sc,config=label,n=400,events=ncoll,rate=ncoll/400,
              wilson=wilson(ncoll,400),conditional_impact_mps=float(r['impact_mps'][r['collision']>0].mean()) if ncoll else None,
              **{k:float(v.mean()) for k,v in r.items() if k!='collision'}))
    for sc in ['brake','cruise']:
        for p in PROFILES:
            evaluate(p,sc,'off')
            evaluate(p,sc,'local3',local=True)
            evaluate(p,sc,'local7',local=True,nominal_limit=7)
            evaluate(p,sc,'remote7',nominal_limit=7)
            evaluate(p,sc,'local_fallback200',threshold=200,fallback='local')
            for force in [3,4,7]:
                for th in THRESHOLDS:evaluate(p,sc,f'stop{force}_{th}',threshold=th,force=force)
            print(sc,p,'core complete',count,flush=True)
    # A denser sweep is restricted to the key jitter and loss profiles, force=3.
    for sc in ['brake','cruise']:
        for p in ['P1','P2']:
            for th in range(60,251,10):evaluate(p,sc,f'stop3_{th}',threshold=th,force=3)
    csvout('episodes.csv',rows)
    csvout('summary.csv',[{k:v for k,v in x.items() if k!='wilson'} for x in summary])
    rng=np.random.default_rng(SEED+2);idx=rng.integers(0,400,(10000,400));contrasts=[]
    for sc in ['brake','cruise']:
        for p in PROFILES:
            for label in ['stop3_200','stop4_200','stop7_200','local_fallback200','local3','local7','remote7']:
                for metric in ['collision','distance_m','near_s','stopped_while_lead_moves_s','impact_squared']:
                    delta=raw[(p,sc,label)][metric]-raw[(p,sc,'off')][metric]
                    b=delta[idx].mean(axis=1)
                    contrasts.append(dict(profile=p,scenario=sc,config=label,metric=metric,delta=float(delta.mean()),
                        low=float(np.quantile(b,.025)),high=float(np.quantile(b,.975))))
    csvout('contrasts.csv',contrasts)
    # Robustness checks: change event clocks and phase, not only physics.
    sens=[];n=100;small={k:v[:n] for k,v in c.items()}
    for p in ['P1','P2']:
        for name,kw in [('random_strict',{}),('aligned_strict',{'phase':np.zeros(n)}),
                ('random_inclusive',{'inclusive':True}),('aligned_inclusive',{'phase':np.zeros(n),'inclusive':True}),
                ('local5ms',{'dt':.005,'local_tick':.005}),('local20ms',{'local_tick':.02}),
                ('recovery1',{'recovery':1}),('recovery5',{'recovery':5})]:
            defaults=dict(phase=phase[:n],threshold=200,force=3);defaults.update(kw)
            r=simulate(small,tuple(x[:n] for x in net[p]),**defaults)
            sens.append(dict(profile=p,variant=name,n=n,events=int(r['collision'].sum()),fallback_s=float(r['fallback_s'].mean()),distance_m=float(r['distance_m'].mean())))
    csvout('clock_sensitivity.csv',sens)
    # Analytic and limiting-case assertions, plus a fresh disjoint pilot.
    x,v=advance(np.array([0.]),np.array([1.]),np.array([-4.]),1.)
    assert np.allclose(x,.125) and np.allclose(v,0)
    assert np.all(nominal(np.array([100.]),np.array([0.]),np.array([0.]))==1.5)
    assert np.all(nominal(np.array([0.]),np.array([16.]),np.array([0.]))==-3)
    assert np.allclose(raw[('P0','brake','local3')]['distance_m'],raw[('P3','brake','local3')]['distance_m'])
    pilot=sample(20,SEED-10);pn=network(20,SEED-11)
    for sc in ['brake','cruise']:
        for p in PROFILES:
            for f in [3,4,7]:
                r=simulate(pilot,pn[p],threshold=200,force=f,scenario=sc)
                assert all(np.isfinite(v).all() for v in r.values())
    result=dict(seed=SEED,python=platform.python_version(),numpy=np.__version__,main_runs=count,
                pilot_runs=480,sensitivity_runs=1600,summary=summary,contrasts=contrasts,sensitivity=sens,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (ROOT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('DONE',count,'main runs',flush=True)
if __name__=='__main__':run()
