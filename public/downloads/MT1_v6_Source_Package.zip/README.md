# Midterm 1 release MT1-v6-20261018

Authors: Zhakiyan Baktiyaruly and Damirlan Zhetpissov. International IT University, Almaty, Kazakhstan. Emails: 39579@iitu.edu.kz; 39514@iitu.edu.kz.

## Final manuscript and interpretation

12 PDF pages; 250-word / 1,556-character abstract; 20 cited references; five original figures, four tables and an editable code listing. Final content is content_v6.py; earlier content modules remain imports needed by the builder. Prior delivered versions are preserved in separate directories.

This revision adds no simulation runs. It reports the asymmetry explicitly: at 200 ms Remote 7 has fewer braking collisions and less cruise loss than Stop 7 in P2 and P3R. Stop 7 has fewer collisions only in deliberately hazard aligned fixed P3, at about 35% cruise distance loss. The compared systems are strong nominal control without backup and weak nominal control with strong backup. Strong nominal control plus backup was not tested.

The 51-of-53 concentration of avoided events in the overlap group applies to equal force Stop 3. Strong Stop 7 reduces events both in overlap (81 to 0 versus Off) and without overlap (45 to 29). Stratification is descriptive, without intervals for within-stratum contrasts; the graph has Wilson intervals for the individual proportions. RQ4 formalizes the exploratory architecture and outage-schedule comparison, not a preregistered confirmatory question.

Discussion explains the low-threshold negative controls, the strict-comparison/grid/event-order boundary in P1, and the paired Stop 3 versus Switch 3 cruise difference. Table 4 now gives all three stopping forces at 100/150/200/250/400 ms, with collision counts and cruise loss rounded to three decimals. Exact full sweep coordinates remain in sweep_tradeoff.csv. The code listing is in the methods, and content has been redistributed to reduce unnecessary page gaps.

## Data and provenance

There are 107,200 main runs in 268 cells of 400 matched cases: 99,200 original revision episodes and 8,000 supplemental episodes. These reuse 400 independent physical cases; they are not 107,200 independent samples. Additional pilot 480 and illustrative clock 1,600 runs are separate.

- episodes.csv, summary.csv, results.json: 99,200 observations and summaries.
- supplement_episodes.csv, supplement_summary.csv, supplement_results.json: 8,000 additional observations; original stage release metadata is retained.
- cases.csv, network_traces.npz: physical inputs, generation phases and original network draws.
- outage_manifest.csv, random_outage_traces.npz: one random outage window per case, seed 20261022.
- outage_overlap.csv, stratified_outcomes.csv, interpretation_analysis.json: descriptive braking-interval exposure analysis. Original reanalysis metadata is retained; the final manuscript release is identified by this README and archive name.
- contrasts.csv, supplement_contrasts.csv, extra_analysis.json: paired contrasts and intervals.
- clock_sensitivity.csv: illustrative 100-case implementation checks.
- table3_outcomes.csv and table4_sweep.csv: final tables; sweep_tradeoff.csv: all available paired threshold coordinates.
- SOURCE_CHECKS.md: primary-source bibliographic and claim checks, including the full-text access limit for reference 18.

P3 fixed outage [1.5,3.0) s always contains lead brake onset and is not a neutral fault sample or a proved worst case. P3R start is uniform [0,8.5] s with 1.5 s duration. Positive overlap uses [t_b,t_b+v0/a_L), independent of follower collision truncation. There are 186 overlapping and 214 nonoverlapping cases; only 66 windows contain onset. Only one physical/network trace pair and one P3R window are drawn per case.

The contact proxy J averages squared sampled relative contact speed over all 400 cases with zero for noncollisions. It is not collision energy or injury risk. Cruise intervention time and entries have no collision truncation. Local references are complete alternatives with different update rates and delay, not isolated freshness tests. Random emergency timers, state-triggered emergency braking, continuous clocks and realistic vehicle/network dynamics remain untested.

## Reproduction

Use Python and NumPy: run `python experiment.py`, `python extra_analysis.py`, `python supplement.py`, then `python interpretation_analysis.py`. Base software versions are in results.json. Seeds: physical 20261018, original network 20261019, source phase 20261021, bootstrap 20261020, random outage 20261022. Source paths are relative to the script.

Rebuild graphics with `python revision_assets.py`, then documents with `python build_article.py`. Layout needs reportlab, python-docx, Pillow and pypdfium2; font/runtime paths are host-specific. Numerical experiments do not require layout packages. The inherited screenshot helper is retained for provenance but is not needed for the final editable listing and vector figures.

Run `python verify_package.py` to check every episode count and cell mean, braking-interval strata, final table values and document structure, then generate MT1_v6_Source_Package.zip. SHA256.json identifies the exact packaged files, excluding itself and the enclosing ZIP. Obsolete unused figures and old table exports are excluded. The source archive does not include external papers or duplicate final PDF/DOCX files.

## Formatting and verification

Selected journal: Scientific Journal of Astana IT University, supplied KOKSON workbook worksheet Список 2 row 106. Formatting basis: https://sj.astanait.edu.kz/ru/trebovaniya-k-oformleniyu-stati/

English, A4, Times New Roman 12 body, single spacing; margins top/bottom/left/right 20/25/30/15 mm. Abstract kept at 250 words because that is the selected journal minimum. References are numbered by citation order with APA-style entries. All 12 PDF pages were rendered and visually reviewed. Word and LibreOffice are absent, so DOCX visual pagination is not verified; use the checked PDF for layout.

This is a course manuscript, not a completed journal submission. Department, ORCID, credentials and funding have not been invented. Equation is editable text, not MathType. No upload or payment was made. Code, text and original graphics were prepared with AI assistance; authors should review and follow course disclosure requirements.
