from build_assets import *
from base_model import wilson
AData=json.loads((ROOT/'interpretation_analysis.json').read_text())
# Stratified P3R, all conditional denominators explicit.
d=Drawing(480,245)
for pi,label in enumerate(['overlap','no_overlap']):
 rows=[r for r in AData['strata'] if r['stratum']==label];n=rows[0]['n']
 x0=43+pi*236;y0=48;h=147;w=188
 text(d,x0,225,('Braking overlap' if pi==0 else 'No braking overlap')+f' | n={n}',11)
 for tick in [0,10,20,30,40,50,60]:
  y=y0+tick/60*h;line(d,x0,y,x0+w,y,GRAY)
  if pi==0:text(d,x0-5,y-3,tick,9,anchor='end')
 for j,r in enumerate(rows):
  x=x0+4+j*31;rate=r['events']/n
  d.add(Rect(x,y0,18,rate/0.6*h,fillColor=BLUE,strokeColor=None))
  lo,hi=wilson(r['events'],n);line(d,x+9,y0+lo/.6*h,x+9,y0+hi/.6*h)
  text(d,x+9,y0+hi/.6*h+5,r['events'],9,anchor='middle')
  text(d,x+9,y0-15,['Off','S3','S4','S7','Sw3','R7'][j],9,anchor='middle')
text(d,7,204,'%');text(d,240,8,'Collision proportions; labels: events; bars: 95% Wilson intervals',10,anchor='middle')
save(d,'fig3_strata')
# Full existing threshold sweep, no interpolation or selected optimum.
d=Drawing(480,310)
cols={3:BLUE,4:ORANGE,7:colors.HexColor('#697A63')}
for j,(f,col) in enumerate(cols.items()):
 d.add(Circle(42+j*100,292,3,fillColor=col,strokeColor=None));text(d,50+j*100,289,'Stop '+str(f),10)
text(d,342,289,'All available thresholds',10)
for pi,p in enumerate(['P1','P2']):
 x0=39+pi*238;y0=59;w=197;h=194
 X=lambda loss:x0+(loss+2)/102*w
 Y=lambda rate:y0+rate/.35*h
 text(d,x0,267,p+' | brakes vs cruise cost',11)
 for tick in [0,10,20,30,35]:
  y=Y(tick/100);line(d,x0,y,x0+w,y,GRAY)
  if pi==0:text(d,x0-4,y-3,tick,9,anchor='end')
 for tick in [0,25,50,75,100]:text(d,X(tick),y0-15,tick,9,anchor='middle')
 base=S[(p,'cruise','off')]['distance_m']
 for f,col in cols.items():
  for key,b in S.items():
   if key[0]!=p or key[1]!='brake' or not key[2].startswith(f'stop{f}_'):continue
   ck=(p,'cruise',key[2])
   if ck not in S:continue
   loss=base-S[ck]['distance_m'];d.add(Circle(X(loss),Y(b['rate']),2.5,fillColor=col,strokeColor=None))
 for conf,label,dy in [('off','Off',10),('local3','Local 3',8),('remote7','Remote 7 / Local 7',17)]:
  b=S[(p,'brake',conf)];c=S[(p,'cruise',conf)];x=X(base-c['distance_m']);y=Y(b['rate'])
  d.add(Rect(x-3,y-3,6,6,fillColor=colors.white,strokeColor=colors.black));line(d,x+4,y+2,x+16,y+dy-2);text(d,x+18,y+dy-4,label,9,col=colors.black)
 # Local 7 overlaps Remote 7 at this plotting scale; retain its exact point in data.
 b=S[(p,'brake','local7')];c=S[(p,'cruise','local7')];d.add(Circle(X(base-c['distance_m']),Y(b['rate']),4,fillColor=None,strokeColor=colors.black))
text(d,7,257,'%');text(d,240,20,'x: mean cruise distance loss vs Off (m); y: braking collisions (%)',11,anchor='middle')
text(d,240,5,'Points are paired means / proportions; overlapping points retained; no interpolation',9,anchor='middle')
save(d,'fig4_sweep')
# Descriptive exposure histogram, explicitly no fitted failure distribution.
starts=np.array([float(x['start_s']) for x in outages]);hist,edges=np.histogram(starts,bins=np.linspace(0,8.5,10))
d=Drawing(480,150);x0=38;y0=31;w=285;h=94
for tick in [0,20,40,60]:
 y=y0+tick/60*h;line(d,x0,y,x0+w,y,GRAY);text(d,x0-4,y-3,tick,8,anchor='end')
for j,n in enumerate(hist):d.add(Rect(x0+j*w/9+2,y0,w/9-4,n/60*h,fillColor=BLUE,strokeColor=None))
for tick in [0,2,4,6,8.5]:text(d,x0+tick/8.5*w,y0-13,tick,9,anchor='middle')
text(d,30,138,'Cases');text(d,180,2,'Outage start (s), 9 equal bins',9,anchor='middle')
text(d,340,110,'Onset inside: 66 / 400',10);text(d,340,88,'Braking overlap: 186 / 400',10);text(d,340,66,'No overlap: 214 / 400',10)
save(d,'fig5_exposure')
print('Created v4 interpretation figures')
