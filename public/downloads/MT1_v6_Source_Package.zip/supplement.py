"""Targeted v3 additions; keeps v2 main observations unchanged.
Run experiment.py first only when regenerating v2 data from scratch.
"""
from pathlib import Path
import csv,json
import numpy as np
from experiment import simulate
from base_model import wilson
ROOT=Path(__file__).resolve().parent

def write(name,rows):
    with (ROOT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def run():
    manifest=list(csv.DictReader((ROOT/'cases.csv').open()))
    c={k:np.array([float(x[k]) for x in manifest]) for k in ['v','gap','brake','onset']}
    phase=np.array([float(x['phase_s']) for x in manifest])
    traces=np.load(ROOT/'network_traces.npz')
    starts=np.random.default_rng(20261022).uniform(0,8.5,400)
    tx=np.arange(200)[None,:]*.05+phase[:,None]
    loss=(tx>=starts[:,None]) & (tx<starts[:,None]+1.5)
    randomized=(np.full((400,200),.02),loss)
    np.savez_compressed(ROOT/'random_outage_traces.npz',delay=randomized[0],loss=loss)
    write('outage_manifest.csv',[dict(case=i,start_s=float(starts[i]),end_s=float(starts[i]+1.5),
        contains_brake_onset=int(starts[i]<=np.ceil(c['onset'][i]/.01-1e-9)*.01<starts[i]+1.5)) for i in range(400)])
    out=[];summary=[]
    def evaluate(profile,scenario,conf,trace,**kwargs):
        r=simulate(c,trace,phase=phase,scenario=scenario,**kwargs)
        for i in range(400):out.append(dict(case=i,profile=profile,scenario=scenario,config=conf,**{k:float(v[i]) for k,v in r.items()}))
        events=int(r['collision'].sum())
        summary.append(dict(profile=profile,scenario=scenario,config=conf,n=400,events=events,rate=events/400,wilson=wilson(events,400),
            **{k:float(v.mean()) for k,v in r.items() if k!='collision'}))
    for p in ['P1','P2']:
        tr=(traces[p+'_delay'],traces[p+'_loss'])
        for f in [4,7]:
            for th in [190,210]:evaluate(p,'brake',f'stop{f}_{th}',tr,threshold=th,force=f)
    for sc in ['brake','cruise']:
        evaluate('P3R',sc,'off',randomized)
        evaluate('P3R',sc,'remote7',randomized,nominal_limit=7)
        evaluate('P3R',sc,'local_fallback200',randomized,threshold=200,fallback='local')
        for f in [3,4,7]:evaluate('P3R',sc,f'stop{f}_200',randomized,threshold=200,force=f)
    write('supplement_episodes.csv',out)
    write('supplement_summary.csv',[{k:v for k,v in s.items() if k!='wilson'} for s in summary])
    # Build selected matched arrays from both stages, retaining all cases.
    groups={}
    for name in ['episodes.csv','supplement_episodes.csv']:
        for row in csv.DictReader((ROOT/name).open()):
            if row['scenario']=='brake':
                key=(row['profile'],row['config'])
                groups.setdefault(key,[]).append(row)
    for vals in groups.values():vals.sort(key=lambda r:int(r['case']))
    rng=np.random.default_rng(20261020);idx=rng.integers(0,400,(10000,400))
    comparisons=[]
    def compare(p,a,b,metric):
        x=np.array([float(r[metric]) for r in groups[(p,a)]])-np.array([float(r[metric]) for r in groups[(p,b)]])
        boot=x[idx].mean(axis=1)
        comparisons.append(dict(profile=p,a=a,b=b,metric=metric,delta=float(x.mean()),low=float(np.quantile(boot,.025)),high=float(np.quantile(boot,.975))))
    for p in ['P1','P2']:
        for th in [190,200,210]:
            compare(p,f'stop3_{th}','off','collision')
            compare(p,f'stop4_{th}',f'stop3_{th}','collision')
            compare(p,f'stop7_{th}',f'stop3_{th}','collision')
    for p in ['P0','P1','P2','P3','P3R']:
        for a in ['stop3_200','stop4_200','stop7_200','local_fallback200','remote7']:
            compare(p,a,'off','impact_squared')
    for a in ['stop3_200','stop4_200','stop7_200','local_fallback200','remote7']:compare('P3R',a,'off','collision')
    write('supplement_contrasts.csv',comparisons)
    all_summary=json.loads((ROOT/'results.json').read_text())['summary']+summary
    lookup={(s['profile'],s['scenario'],s['config']):s for s in all_summary}
    principal=[]
    for p in ['P0','P1','P2','P3','P3R']:
        for conf in ['off','stop3_200','stop4_200','stop7_200','local_fallback200','remote7']:
            b=lookup[(p,'brake',conf)];cr=lookup[(p,'cruise',conf)]
            principal.append(dict(profile=p,config=conf,n=400,events=b['events'],near_s=b['near_s'],fallback_s=b['fallback_s'],
                impact_squared=b['impact_squared'],cruise_distance_m=cr['distance_m']))
    write('principal_outcomes_v3.csv',principal)
    result=dict(release='MT1-v3-20261018',archive='MT1_v3_Source_Package.zip',additional_main_runs=len(out),total_main_runs=99200+len(out),
                random_onset_contained_cases=int(sum((starts<=np.ceil(c['onset']/.01-1e-9)*.01)&(np.ceil(c['onset']/.01-1e-9)*.01<starts+1.5))),
                summary=summary,comparisons=comparisons)
    (ROOT/'supplement_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__':run()
