# Primary-source checks for references 5, 18, and 20

Checked 18 October 2026. Bibliographic data and the limited claims made in the article were compared with the following primary sources. No external publication PDF is redistributed in this package.

## Reference 5

Alsuhaim, Rayamajhi, Westall, and Martin (2021), IEEE Transactions on Vehicular Technology 70(12), 12691–12702, DOI 10.1109/TVT.2021.3119620.

Author-hosted full paper: https://people.computing.clemson.edu/~jmarty/papers/Adapting_Time_Headway_in_Cooperative_Adaptive_Cruise_Control_to_Network_Reliability.pdf

The title, authors, volume, issue, year, page range, and DOI match. Its abstract and methods describe headway adaptation using a network reliability metric based on burst loss, platoon string stability, and fallback using onboard sensing. Our article cites that mechanism as related work, not an implemented baseline or proof of our controller.

## Reference 18

Takuma, Okuda, and Suzuki (2022), session 1P1-E11, DOI 10.1299/jsmermd.2022.1P1-E11.

Publisher record and public abstract: https://www.jstage.jst.go.jp/article/jsmermd/2022/0/2022_1P1-E11/_article/-char/ja/

English publisher metadata: https://www.jstage.jst.go.jp/article/jsmermd/2022/0/2022_1P1-E11/_article/-char/en

The title, authors, date, session, and DOI match. The public abstract describes a predictive view based on delayed measurements, operation history and a vehicle model, compared with a virtual leader-follower teleoperation approach in a driving simulator. The article makes only a general related-work statement tied explicitly to this published abstract. Full-PDF access redirected to subscriber authentication, so full-text methods and results were not independently verified. No numerical effectiveness or superiority claim is attributed to this source.

## Reference 20

Urša Zrimšek and Erik Štrumbelj, Quantifying Uncertainty: All We Need is the Bootstrap?, arXiv 2403.20182, version 3, revised 14 October 2025.

Version record: https://arxiv.org/abs/2403.20182v3

Full text: https://arxiv.org/html/2403.20182v3

Authors, title, version, year, and identifier match the citation (which uses ASCII transliteration). The full text compares confidence-interval methods across sample sizes, data-generating distributions and statistical functionals. It supports the narrow statement that interval performance depends on method and data. It does not validate our particular paired percentile intervals or quantify our model error.
