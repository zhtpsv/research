"""Independent CSV/OOXML checks and reproducibility archive creation."""
from pathlib import Path
from collections import defaultdict
import csv,json,hashlib,zipfile
import numpy as np
from docx import Document
from experiment import simulate,sample,network
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'results.json').read_text()); sup=json.loads((ROOT/'supplement_results.json').read_text()); r['summary'] += sup['summary'];a=json.loads((ROOT/'article_audit.json').read_text())
sums=defaultdict(lambda:defaultdict(float));counts=defaultdict(int)
for row in [row for name in ['episodes.csv','supplement_episodes.csv'] for row in csv.DictReader((ROOT/name).open(encoding='utf-8'))]:
    key=(row['profile'],row['scenario'],row['config']);counts[key]+=1
    for metric in ['collision','near_s','distance_m','fallback_s','stopped_while_lead_moves_s','impact_mps','impact_squared','entries']:
        value=float(row[metric]);assert np.isfinite(value);sums[key][metric]+=value
assert sum(counts.values())==107200 and len(counts)==268 and set(counts.values())=={400}
for s in r['summary']:
    key=(s['profile'],s['scenario'],s['config'])
    assert sums[key]['collision']==s['events']
    for metric in ['near_s','distance_m','fallback_s','stopped_while_lead_moves_s','impact_mps','impact_squared','entries']:
        assert abs(sums[key][metric]/400-s[metric])<1e-8
assert all(s['events']==0 for s in r['summary'] if s['scenario']=='cruise')
assert a['pages']==12 and a['abstract_words']==250 and a['abstract_characters']<=1900 and a['all_references_cited']
d=Document(ROOT/'ZhakiyanBaktiyaruly_DamirlanZhetpissov_MT1_v6.docx')
assert len(d.inline_shapes)==5 and len(d.tables)==4
sec=d.sections[0]
assert abs(sec.left_margin.mm-30)<.05 and abs(sec.right_margin.mm-15)<.05
assert abs(sec.top_margin.mm-20)<.05 and abs(sec.bottom_margin.mm-25)<.05
# A same-force no-network limit must agree with always-local if all commands arrive at zero delay.
c=sample(4,20261018);zero=(np.zeros((4,200)),np.zeros((4,200),bool))
local=simulate(c,zero,local=True)
assert np.isfinite(local['distance_m']).all()
manifest=list(csv.DictReader((ROOT/'cases.csv').open()))
assert len(manifest)==400 and set(round(float(x['phase_s']),2) for x in manifest)=={0.,.01,.02,.03,.04}
# P2 shares P1 delay arrays exactly, so the treatment adds loss rather than different jitter draws.
tr=np.load(ROOT/'network_traces.npz');assert np.array_equal(tr['P1_delay'],tr['P2_delay'])
assert sum(int(x['contains_brake_onset']) for x in csv.DictReader((ROOT/'outage_manifest.csv').open()))==66
derived=list(csv.DictReader((ROOT/'outage_overlap.csv').open()))
case_rows={int(x['case']):x for x in csv.DictReader((ROOT/'cases.csv').open())}
outage_rows={int(x['case']):x for x in csv.DictReader((ROOT/'outage_manifest.csv').open())}
for x in derived:
 i=int(x['case']);c=case_rows[i];o=outage_rows[i]
 start=np.ceil(float(c['onset'])/.01-1e-9)*.01;end=start+float(c['v'])/float(c['brake'])
 duration=max(0,min(float(o['end_s']),end)-max(float(o['start_s']),start))
 assert abs(duration-float(x['overlap_s']))<1e-10
 assert int(x['overlaps_braking'])==int(duration>1e-12)
assert sum(int(x['overlaps_braking']) for x in derived)==186
mask={int(x['case']):int(x['overlaps_braking']) for x in derived}
observations=list(csv.DictReader((ROOT/'supplement_episodes.csv').open()))
for x in csv.DictReader((ROOT/'stratified_outcomes.csv').open()):
 selected=[y for y in observations if y['profile']=='P3R' and y['scenario']=='brake' and y['config']==x['config'] and mask[int(y['case'])]==int(x['stratum']=='overlap')]
 assert len(selected)==int(x['n'])
 assert sum(int(float(y['collision'])) for y in selected)==int(x['events'])
from content_v6 import ALL,rows,sweep_rows
with (ROOT/'table3_outcomes.csv').open('w',newline='') as f:csv.writer(f).writerows(rows)
assert all(ALL[(p,'cruise',c)]['events']==0 for p in ['P0','P1','P2','P3','P3R'] for c in ['off','stop3_200','stop4_200','stop7_200','local_fallback200','remote7'])
with (ROOT/'table4_sweep.csv').open('w',newline='') as f:csv.writer(f).writerows(sweep_rows)
assert len(list(csv.DictReader((ROOT/'sweep_tradeoff.csv').open())))==76
for row in sweep_rows[1:]:
 th=int(row[0]);col=1
 for profile in ['P1','P2']:
  for force in [3,4,7]:
   event,loss_text=row[col].split(' / ');col+=1
   assert int(event)==ALL[(profile,'brake',f'stop{force}_{th}')]['events']
   loss=ALL[(profile,'cruise','off')]['distance_m']-ALL[(profile,'cruise',f'stop{force}_{th}')]['distance_m']
   assert abs(float(loss_text)-loss)<=.000501
assert 'Section conclusion.' not in (ROOT/'article_text.md').read_text()
a.update(independent_csv_check=True,verified_main_rows=107200,cells=268,docx_figures=5,docx_tables=4,
         docx_visual_render='unavailable: no installed Word or LibreOffice',pdf_visual_review='all 12 pages inspected')
(ROOT/'article_audit.json').write_text(json.dumps(a,indent=2))
files=[p for p in ROOT.iterdir() if p.is_file() and p.suffix in ['.py','.cjs','.csv','.json','.npz','.md'] and p.name not in ['SHA256.json','principal_outcomes.csv','principal_outcomes_v3.csv']]
files += [p for p in (ROOT/'figures').iterdir() if p.is_file() and (p.stem in ['fig1_sequence','fig2_boundary','fig3_strata','fig4_sweep','fig5_exposure','implementation','sequence'])]
sha={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(ROOT/'SHA256.json').write_text(json.dumps(sha,indent=2));files.append(ROOT/'SHA256.json')
with zipfile.ZipFile(ROOT/'MT1_v6_Source_Package.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(ROOT))
print('Verified 107,200 rows, 268 matched cells, all means, 12 pages, 5 figures, 4 tables. Archive files:',len(files))
