from pathlib import Path
import json, re, html, zipfile, hashlib, textwrap, csv
from docx import Document
from docx.shared import Mm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from reportlab.platypus import SimpleDocTemplate, Paragraph, Preformatted, Image, Table, TableStyle, PageBreak, Spacer, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image as PILImage
import pypdfium2 as pdfium
from content_v6 import *

ROOT=Path(__file__).resolve().parent
with (ROOT/'principal_outcomes.csv').open('w',newline='',encoding='utf-8') as f:csv.writer(f).writerows(full)
STEM='ZhakiyanBaktiyaruly_DamirlanZhetpissov_MT1_v6'
R=json.loads((ROOT/'results.json').read_text())
for name,file in [('Times','times.ttf'),('TimesBold','timesbd.ttf'),('TimesItalic','timesi.ttf')]:
    pdfmetrics.registerFont(TTFont(name,'C:/Windows/Fonts/'+file))
pdfmetrics.registerFontFamily('Times',normal='Times',bold='TimesBold',italic='TimesItalic',boldItalic='TimesBold')
WIDTH=165*mm-12; HEIGHT=252*mm
styles={
 'p':ParagraphStyle('body',fontName='Times',fontSize=12,leading=14,alignment=TA_JUSTIFY,firstLineIndent=10*mm,spaceAfter=3),
 'h':ParagraphStyle('heading',fontName='TimesBold',fontSize=12,leading=14,spaceBefore=7,spaceAfter=5,keepWithNext=True),
 'title':ParagraphStyle('title',fontName='TimesBold',fontSize=14,leading=16,alignment=TA_CENTER,spaceAfter=8),
 'authors':ParagraphStyle('authors',fontName='TimesBold',fontSize=12,leading=14,alignment=TA_CENTER,spaceAfter=6),
 'center':ParagraphStyle('center',fontName='Times',fontSize=11,leading=13,alignment=TA_CENTER,spaceAfter=3),
 'caption':ParagraphStyle('caption',fontName='Times',fontSize=10,leading=11.5,alignment=TA_LEFT,spaceAfter=5),
 'ref':ParagraphStyle('ref',fontName='Times',fontSize=11,leading=12.7,spaceAfter=6,leftIndent=15,firstLineIndent=-15),
 'cell':ParagraphStyle('cell',fontName='Times',fontSize=10,leading=11.5,alignment=TA_LEFT),
 'eq':ParagraphStyle('eq',fontName='Times',fontSize=11,leading=14,alignment=TA_CENTER,spaceBefore=4,spaceAfter=5)
}
def fmt(s): return html.escape(s)
def replace_value(s):
    if s=='DYNAMIC_P2':
        c=next(x for x in R['contrasts'] if x['profile']=='P2' and x['threshold_ms']=='200' and x['metric']=='distance_m')
        return f"{c['delta']:.2f} [{c['low']:.2f}, {c['high']:.2f}]"
    return s

doc=Document(); section=doc.sections[0]
section.page_width=Mm(210);section.page_height=Mm(297)
section.top_margin=Mm(20);section.bottom_margin=Mm(25);section.left_margin=Mm(30);section.right_margin=Mm(15)
for name in ['Normal','Title','Heading 1','Caption']:
    st=doc.styles[name];st.font.name='Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
normal=doc.styles['Normal'];normal.font.size=Pt(12)
normal.paragraph_format.line_spacing=1
normal.paragraph_format.space_after=Pt(3)
normal.paragraph_format.first_line_indent=Mm(10)
title=doc.styles['Title'];title.font.size=Pt(14);title.font.bold=True
title.paragraph_format.first_line_indent=Mm(0)
heading=doc.styles['Heading 1'];heading.font.size=Pt(12);heading.font.bold=True
heading.paragraph_format.space_before=Pt(7);heading.paragraph_format.space_after=Pt(5)
heading.paragraph_format.first_line_indent=Mm(0)
foot=section.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');foot._p.append(field)
foot.paragraph_format.first_line_indent=Mm(0)
doc.core_properties.title=TITLE;doc.core_properties.author=AUTHORS
doc.core_properties.subject='Midterm 1 | Original timeout threshold simulation study'

def dp(text,kind='p'):
    p=doc.add_paragraph(style='Heading 1' if kind=='h' else 'Title' if kind=='title' else 'Normal')
    p.add_run(text)
    if kind not in ['p']:
        p.paragraph_format.first_line_indent=Mm(0)
    if kind in ['title','authors','center','eq']:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    elif kind=='p':p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    if text.startswith(('Zhakiyan Baktiyaruly.','Damirlan Zhetpissov.')):p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    if kind in ['caption','center']:p.runs[0].font.size=Pt(10 if kind=='caption' else 11)
    if kind=='authors':p.runs[0].bold=True
    if kind=='eq':p.runs[0].font.size=Pt(11)
    return p

def doc_table(rows,widths,compact=False):
    table=doc.add_table(rows=1,cols=len(rows[0]));table.autofit=False
    for i,w in enumerate(widths):table.columns[i].width=Pt(w/WIDTH*WIDTH)
    for ri,row in enumerate(rows):
        cells=table.rows[0].cells if ri==0 else table.add_row().cells
        for ci,val in enumerate(row):
            c=cells[ci];c.width=Pt(widths[ci]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p=c.paragraphs[0];p.paragraph_format.first_line_indent=Mm(0);p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(2)
            run=p.add_run(replace_value(val));run.font.size=Pt(9.5 if compact else 10);run.bold=ri==0
            pr=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
            for side in ['top','left','bottom','right']:
                x=OxmlElement('w:'+side);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');b.append(x)
            pr.append(b)
            mar=OxmlElement('w:tcMar')
            for side in ['top','left','bottom','right']:
                x=OxmlElement('w:'+side);x.set(qn('w:w'),'45' if compact else '65');x.set(qn('w:type'),'dxa');mar.append(x)
            pr.append(mar)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E9EFF3');pr.append(sh)
        if ri==0:
            repeat=OxmlElement('w:tblHeader');table.rows[0]._tr.get_or_add_trPr().append(repeat)
        no=OxmlElement('w:cantSplit');table.rows[-1]._tr.get_or_add_trPr().append(no)

story=[];page_heights=[]
for pi,page in enumerate(PAGES):
    if pi:story.append(PageBreak());doc.add_page_break()
    flows=[]
    for el in page:
        kind=el[0]
        if kind in styles and kind not in ['caption','ref','cell']:
            s=el[1];dp(s,kind);flows.append(Paragraph(fmt(s),styles[kind]))
        elif kind=='l':
            _,code,caption=el
            p=doc.add_paragraph();p.paragraph_format.first_line_indent=Mm(0);p.paragraph_format.line_spacing=1;p.paragraph_format.space_after=Pt(4)
            run=p.add_run(code);run.font.name='Courier New';run.font.size=Pt(8)
            dp(caption,'caption')
            ls=ParagraphStyle('listing',fontName='Courier',fontSize=8,leading=10)
            flows.append(KeepTogether([Preformatted(code,ls),Paragraph(fmt(caption),styles['caption'])]))
        elif kind=='f':
            _,name,caption,maxheight=el
            file=ROOT/'figures'/(name+'.png');im=PILImage.open(file);w,h=im.size
            scale=min(WIDTH/w,maxheight/h);pw=w*scale;ph=h*scale
            p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Mm(0);p.paragraph_format.space_after=Pt(2)
            p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(file),width=Pt(pw),height=Pt(ph))
            dp(caption,'caption')
            flows.append(KeepTogether([Image(str(file),width=pw,height=ph),Paragraph(fmt(caption),styles['caption'])]))
        elif kind=='t':
            _,caption,rows,widths=el
            widths=[x/sum(widths)*WIDTH for x in widths]
            dp(caption,'caption');compact=caption.startswith(('Table 3.','Table 4.'));doc_table(rows,widths,compact)
            cellstyle=ParagraphStyle('compact',parent=styles['cell'],fontSize=9.5,leading=10.5) if compact else styles['cell']
            cells=[[Paragraph(fmt(replace_value(x)),cellstyle) for x in row] for row in rows]
            t=Table(cells,colWidths=widths,hAlign='LEFT')
            t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.5,colors.HexColor('#D9D9D9')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E9EFF3')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),2.5 if compact else 5),('BOTTOMPADDING',(0,0),(-1,-1),2.5 if compact else 5)]))
            flows.append(KeepTogether([Paragraph(fmt(caption),styles['caption']),t,Spacer(1,6)]))
        elif kind=='refs':
            for i in range(el[1],el[2]):
                desc,url=REFERENCES[i];s=f'[{i+1}] {desc} {url}'
                p=dp(s);p.alignment=WD_ALIGN_PARAGRAPH.LEFT;p.paragraph_format.first_line_indent=Pt(-15);p.paragraph_format.left_indent=Pt(15);p.paragraph_format.space_after=Pt(6)
                for run in p.runs:run.font.size=Pt(11)
                flows.append(Paragraph(fmt(f'[{i+1}] {desc} ')+f'<link href="{html.escape(url)}" color="#173547">{html.escape(url)}</link>',styles['ref']))
    # Measure actual flowables, including nested KeepTogether content.
    def measure(f):
        if isinstance(f,KeepTogether):return sum(measure(x) for x in f._content)
        return f.wrap(WIDTH,10000)[1]+f.getSpaceBefore()+f.getSpaceAfter()
    page_heights.append(sum(measure(x) for x in flows))
    story.extend(flows)
doc.save(ROOT/(STEM+'.docx'))
def footer(canvas,document):
    canvas.setFont('Times',10);canvas.drawCentredString(112.5*mm,13*mm,str(document.page))
pdf=SimpleDocTemplate(str(ROOT/(STEM+'.pdf')),pagesize=(210*mm,297*mm),leftMargin=30*mm,rightMargin=15*mm,topMargin=20*mm,bottomMargin=25*mm,title=TITLE,author=AUTHORS)
pdf.build(story,onFirstPage=footer,onLaterPages=footer)
qa=ROOT/'pdf_qa';qa.mkdir(exist_ok=True)
p=pdfium.PdfDocument(str(ROOT/(STEM+'.pdf')))
texts=[]
for i,page in enumerate(p):
    page.render(scale=1.5).to_pil().save(qa/f'page-{i+1:02}.png')
    tp=page.get_textpage();texts.append(tp.get_text_range());tp.close()
audit={'pages':len(p),'intended_pages':len(PAGES),'estimated_page_heights_pt':page_heights,'available_height_pt':HEIGHT-12,'abstract_words':len(ABSTRACT.split()),'abstract_characters':len(ABSTRACT),'references':len(REFERENCES),'all_references_cited':all(re.search(r'\['+str(i)+r'(?:,|\])',' '.join(str(x) for page in PAGES for x in page)) for i in range(1,21)), 'pdf_words':sum(len(t.split()) for t in texts),'main_runs':SUP['total_main_runs']}
(ROOT/'article_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
(qa/'extracted.txt').write_text('\n\n'.join(texts),encoding='utf-8');p.close()
(ROOT/'article_text.md').write_text('\n\n'.join(el[1] for page in PAGES for el in page if el[0] in ['h','p','title','authors','center','eq']),encoding='utf-8')
print(json.dumps(audit,indent=2))
