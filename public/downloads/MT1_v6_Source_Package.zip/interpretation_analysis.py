from pathlib import Path
import csv,json
import numpy as np
R=Path(__file__).resolve().parent
summ=[x for name in ['results.json','supplement_results.json'] for x in json.loads((R/name).read_text())['summary']]
S={(x['profile'],x['scenario'],x['config']):x for x in summ}
C=list(csv.DictReader((R/'cases.csv').open()));O=list(csv.DictReader((R/'outage_manifest.csv').open()))
onset=np.ceil(np.array([float(x['onset']) for x in C])/.01-1e-9)*.01
end=onset+np.array([float(x['v'])/float(x['brake']) for x in C])
start=np.array([float(x['start_s']) for x in O]);finish=start+1.5
overlap=np.maximum(0,np.minimum(finish,end)-np.maximum(start,onset))
mask=overlap>1e-12
with (R/'outage_overlap.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['case','outage_start_s','outage_end_s','brake_start_s','brake_end_s','overlap_s','overlaps_braking'])
 for i in range(400):w.writerow([i,start[i],finish[i],onset[i],end[i],overlap[i],int(mask[i])])
D={}
for name in ['episodes.csv','supplement_episodes.csv']:
 for x in csv.DictReader((R/name).open()):
  if x['scenario']=='brake' and x['profile'] in ['P0','P3R']:
   D.setdefault((x['profile'],x['config']),[]).append(x)
for key in D:
 D[key].sort(key=lambda x:int(x['case']))
 assert [int(x['case']) for x in D[key]]==list(range(400))
# Case identities explicitly checked before paired stratification.
print('episode fields',next(iter(D.values()))[0].keys())
rows=[]
for label,m in [('overlap',mask),('no_overlap',~mask)]:
 for conf in ['off','stop3_200','stop4_200','stop7_200','local_fallback200','remote7']:
  vals=np.array([int(float(x['collision'])) for x in D[('P3R',conf)]])
  base=np.array([int(float(x['collision'])) for x in D[('P0','off')]])
  rows.append(dict(stratum=label,config=conf,n=int(m.sum()),events=int(vals[m].sum()),p0_off_events=int(base[m].sum()),excess_events=int((vals[m]-base[m]).sum())))
with (R/'stratified_outcomes.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
# Complete existing force-3 threshold sweep, collision vs cruise distance cost.
sweep=[]
for p in ['P1','P2']:
 base=S[(p,'cruise','off')]['distance_m']
 for force in [3,4,7]:
  for th in sorted(set(int(k[2].split('_')[1]) for k in S if k[0]==p and k[2].startswith(f'stop{force}_'))):
   config=f'stop{force}_{th}'
   if (p,'cruise',config) not in S:continue
   b=S[(p,'brake',config)];c=S[(p,'cruise',config)]
   sweep.append(dict(profile=p,control=config,threshold_ms=th,events=b['events'],rate=b['rate'],cruise_loss_m=base-c['distance_m']))
 for conf in ['off','remote7','local3','local7']:
  b=S[(p,'brake',conf)];c=S[(p,'cruise',conf)]
  sweep.append(dict(profile=p,control=conf,threshold_ms='',events=b['events'],rate=b['rate'],cruise_loss_m=base-c['distance_m']))
with (R/'sweep_tradeoff.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=sweep[0].keys());w.writeheader();w.writerows(sweep)
report=dict(release='MT1-v5-20261018',new_simulation_runs=0,n_overlap=int(mask.sum()),n_no_overlap=int((~mask).sum()),strata=rows,sweep=sweep)
(R/'interpretation_analysis.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='sweep'},indent=2))

