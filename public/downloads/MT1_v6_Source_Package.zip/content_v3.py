"""Final v3 text and layout overrides of the preserved v2 source."""
from article_content import *
SUP=json.loads((ROOT/'supplement_results.json').read_text())
ALL={(x['profile'],x['scenario'],x['config']):x for x in R['summary']+SUP['summary']}
ABSTRACT='''A remote command can become too old to guide a moving vehicle. A local backup may help, but its effect also depends on how hard it brakes and what it does after a timeout. This study compares age limits, brake strength, and complete local control alternatives in an ideal two vehicle model. It does not isolate the value of early action or fresh measurements. Shared cases cover a braking leader and a leader that keeps its speed. Tests impose low delay, jitter, loss, and both fixed and random outage starts. The fixed outage always covers the lead brake onset and is treated as a hazard aligned stress test. The data contain 107,200 runs based on four hundred physical cases. Added tests compare three brake strengths at nearby age limits. Their results show that the size of the extra brake benefit changes with the chosen limit. In the loss profile, the strong nominal remote controller has no collisions, while the strongest backup behind the weak nominal controller still has thirteen. Random outage timing also changes the contrast substantially from the fixed stress schedule. A contact measure averaged over all cases, with zero for no contact, complements counts without selecting only vehicles that collide. Clock tests illustrate implementation sensitivity but do not establish robustness. The findings support explicit controls for brake authority and fault timing, rather than a universal split of benefits. They describe this model and sampled inputs, not a road safety guarantee or a reason to offload a simple controller.'''
PAGES[0][5]=('p',ABSTRACT)

changes={
'The closest communication related comparison is cooperative adaptive cruise control.':'Related work includes cooperative adaptive cruise control.',
'The contribution is a controlled case study separating backup force, fresh local state, and intervention costs.':'The contribution is a case study comparing brake strength and complete backup alternatives, with their intervention costs.',
'RQ4 asks whether behavior near 200 ms is sensitive to comparison semantics, phase, local checks, and recovery count.':'A small timing subset illustrates implementation sensitivity; it is not a separate robustness research question.',
'The primary comparisons use 200 ms in the loss and outage profiles. A wider threshold sweep evaluates sensitivity rather than selecting a deployment optimum.':'The primary backup comparison uses 200 ms. Added force comparisons at 190 and 210 ms in P1/P2 test dependence on that boundary. No share of the total benefit is assumed stable across thresholds.',
'Total main execution is 99,200 episodes.':'A targeted extension adds 3,200 braking episodes for forces 4/7 at 190/210 ms in P1/P2 and 4,800 episodes for six controls in both scenarios with random outage onset. Total main execution is 107,200 episodes.',
'At a fresh 50 ms recovery check, a counter increments;':'Recovery checks occur at global times 0, 50, 100 ms and so on, independently of the randomized command generation phase. At a fresh recovery check, a counter increments;',
'Conditional mean contact speed excludes noncollision cases and is reported with event counts; changing which cases collide can change this conditional mean.':'The principal contact metric J is the mean squared relative contact speed over all 400 cases, with zero for noncollision. Its unit is m2/s2. This avoids conditioning on collision but is still not energy or injury risk.',
'These differences prevent interpreting a threshold at this boundary as robust to implementation details.':'These illustrative differences motivate a fuller timing study; they do not establish phase invariance or robustness.',
'The controller table distinguishes stronger actuation from fresher information.':'The controller table distinguishes brake limits from whole local control alternatives; update rate and delay are not isolated.',
'The defensible finding is a decomposition of effects: brake authority, early intervention, access to local state, and clock semantics all influence the result.':'The findings are controlled comparisons of brake limits and backup architectures. Early intervention and measurement freshness have not been separately identified.',
'A separate 100 case subset tests eight variants in P1/P2, totaling 1,600 runs.':'An illustrative 100 case subset tests eight variants in P1/P2, totaling 1,600 runs. It has no confirmatory intervals and is not used to infer phase invariance.',
'The 99,200 executed main episodes include 400 independent physical draws reused across conditions, not 99,200 independent samples.':'The 107,200 executed main episodes reuse 400 independent physical draws; they are not 107,200 independent samples.',
'A local proportional following controller is evaluated as an alternative backup without calling it verified or safe.':'A local proportional following controller is evaluated as an entire alternative with 10 ms updates, ideal measurements, and no transmission delay; its individual advantages are not separated.',
}
for page in PAGES:
    for i,el in enumerate(page):
        if el[0] in ['p','h']:
            value=el[1]
            for old,new in changes.items():value=value.replace(old,new)
            page[i]=(el[0],value)

# Add the independently randomized outage to the protocol, explicitly distinguishing the stress schedule.
PAGES[3][4]=('p','Remote commands are generated every 50 ms at each case specific phase. A combined delay models sensing, processing, and return; no edge queue or offloading advantage is modeled. The receiver holds the latest accepted command and rejects older timestamps. A zero acceleration command at timestamp zero initializes the receiver. Fixed P3 always contains lead brake onset, making it a deliberately hazard aligned stress schedule, not a neutral outage sample or a proved worst case. P3R independently draws each outage start uniformly from 0 to 8.5 s, with duration 1.5 s and seed 20261022; one shared start is used across controls and scenarios for each case.')
for i,el in enumerate(PAGES[3]):
    if el[0]=='t':
        rows=el[2]
        rows[4]=['P3','20 ms delay; hazard aligned outage [1.5, 3.0) s']
        rows.insert(5,['P3R','20 ms delay; random start U[0,8.5] s, duration 1.5 s'])

# Boundary analysis replaces the redundant reference bar chart; all references remain in Table 2.
for i,el in enumerate(PAGES[5]):
    if el[0]=='f':PAGES[5][i]=('f','fig2_boundary','Figure 2. Braking strength comparison at neighboring thresholds. Each point uses 400 cases; bars are 95% Wilson intervals. Curves can overlap when backup is inactive.',180)
    elif el[0]=='p' and el[1].startswith('Section conclusion.'):
        PAGES[5][i]=('p','At P1, forces 3/4/7 give 82/35/3 collisions at 190 ms, but 112/112/112 at both 200 and 210 ms. In P2, counts are 55/7/0, 95/54/13, and 98/65/22. The extra reduction from force 3 to 4 is 12.00, 10.25, and 8.25 percentage points at these P2 thresholds. Corresponding paired 95% intervals are [9.00,15.25], [7.50,13.25], and [5.75,11.00]. Section conclusion. Benefit magnitudes and their relative shares depend on threshold and profile; the 200 ms split is not a general decomposition.')

# Full principal metric table fits on one page using a compact, readable table style.
metric_rows=[['Profile / control','Events','Near s','Backup s','J m2/s2','Cruise m']]
names={'off':'Off','stop3_200':'Stop 3','stop4_200':'Stop 4','stop7_200':'Stop 7','local_fallback200':'Switch 3'}
for p in ['P0','P1','P2','P3','P3R']:
    for conf in names:
        b=ALL[(p,'brake',conf)];c=ALL[(p,'cruise',conf)]
        metric_rows.append([p+' / '+names[conf],str(b['events']),f"{b['near_s']:.3f}",f"{b['fallback_s']:.3f}",f"{b['impact_squared']:.3f}",f"{c['distance_m']:.2f}"])
PAGES[6]=[
('h','5.2 Full case contact and intervention outcomes'),
('p','Table 3 reports the five principal 200 ms conditions in every profile. Counts, near exposure, backup duration, and J refer to braking cases; cruise distance refers to the matched nonbraking cases. Each cell uses 400 cases. Cruise cases have no collisions. J assigns zero to noncollision cases rather than comparing selected collision subsets.'),
('t','Table 3. Complete principal outcome matrix at 200 ms',metric_rows,[126,42,61,67,76,78]),
('p','In P2, J is 5.098 for Off, 3.922 for Stop 3, 1.875 for Stop 4, and 0.225 for Stop 7; Remote 7 has J = 0. The paired Stop 3 minus Off difference is -1.176 m2/s2 [-1.572,-0.811]. The metric jointly reflects contact frequency and speed, not a pure injury effect. Section conclusion. The complete matrix shows costs and residual contacts without conditioning severity on which cases collide.')
]

PAGES[7]=[
('h','5.3 Outage timing and illustrative clock checks'),
('p','P3 always places the lead brake onset inside the outage. In P3R, only 66 of 400 randomly placed windows contain that onset. The two schedules therefore test different event alignment. Figure 3 compares their braking outcomes; neither represents a measured distribution of radio failures.'),
('f','fig3_outages','Figure 3. Fixed hazard aligned and randomized outages, with 95% Wilson intervals. S3/S4/S7 denote stop force; Sw3 is Switch 3 and R7 is Remote 7. All backups use 200 ms.',190),
('p','With randomized outage start, Off gives 126 collisions and Stop 3 gives 73, a paired difference of -13.25 percentage points [-16.75,-10.00]. Stop 4, Stop 7, Switch 3, and Remote 7 give 42, 29, 86, and 5 events. The much larger fixed schedule contrast, 303 versus 4, cannot be generalized to arbitrary outage timing. J for P3R Stop 3 falls from Off 10.312 to 2.614, with paired difference -7.698 m2/s2 [-10.151,-5.464].'),
('p','Nonbraking controls still expose stopping cost. For fixed P3 at 200 ms, Stop 3 travels 116.00 m and Switch 3 travels 121.21 m: -5.21 m [-5.74,-4.71]. In P3R the corresponding means are 114.50 and 121.21 m. These compare complete backup actions; the local controller also changes update frequency and transmission delay, so they do not isolate freshness.'),
('p','The earlier 100 case timing subset remains an illustration, with its full values supplied in the release. For P1, strict comparison gives 30 collisions and inclusive comparison gives 21. These point differences do not quantify uncertainty or establish phase robustness. The subset is not used for a separate RQ4 conclusion. Section conclusion. Fault alignment changes the measured contrast, while the limited clock checks motivate future tests rather than supporting invariance.')
]

# Narrow the discussion wherever v2 wording implied an identified causal mechanism.
PAGES[8][1]=('p','The neighboring threshold experiment limits any attempt to assign stable shares of benefit. In P2, increasing backup deceleration from 3 to 4 improves counts at 190, 200, and 210 ms, but the magnitude varies. In P1 it helps at 190 ms and has no effect at 200/210 because backup remains inactive. Thus the 200 ms comparison is a defined implementation result, not a threshold invariant split between timing and force.')
PAGES[8][2]=('p','Outage placement is also substantive. Fixed P3 deliberately contains every sampled lead braking onset and can trigger braking before the hazard. Random P3R produces a smaller equal force contrast. Neither experiment identifies the value of early action independently: no matched random braking timer or state triggered emergency policy was tested. Age trigger superiority over those alternatives remains unresolved.')
PAGES[8][3]=('p','The local references are complete architectural alternatives. They use ideal current measurements with 10 ms updates and no transmission delay, versus phased 50 ms remote generation. Their performance cannot be assigned to freshness alone. Local 3 has 77 observed collisions, but this is not a count of physically unavoidable events: its proportional rule can brake too late. Local 7 has zero observed events without constituting an oracle. In P2, Remote 7 has zero collisions whereas Stop 7 behind the weaker nominal controller has 13; that stronger nominal architecture is an important alternative, not evidence that timeout always helps.')

for i,el in enumerate(PAGES[9]):
    if el[0]=='p' and el[1].startswith('Equal force and cruise'):
        PAGES[9][i]=('p','The targeted extensions show that brake strength comparisons depend on the age threshold and that outage timing strongly changes observed benefit. A stronger nominal remote controller can outperform strong backup behind a weaker nominal controller. Full case contact scores complement counts, while nonbraking controls expose stopping cost. Early action and measurement freshness remain unisolated explanations, and the small clock subset provides illustration only. The result supports explicit conditional comparisons, not a universal decomposition, optimal timeout, edge compute advantage, or safety guarantee.')
    elif el[0]=='p' and el[1].startswith('All episode outputs'):
        PAGES[9][i]=('p','Data release MT1-v3-20261018 is supplied as MT1_v3_Source_Package.zip. It contains all main observations, contrasts, software versions, original figures, and SHA256.json file checksums. The archive is the specific reconstruction resource for this article; no public DOI or repository is claimed. Figures 4 and 5 document the implementation and an input audit viewer.')
    elif el[0]=='f' and el[1]=='fig5_code':PAGES[9][i]=('f','fig5_code','Figure 4. Actual implementation excerpt of the following law and exact within step stopping integration.',140)
    elif el[0]=='f' and el[1]=='fig6_viewer':PAGES[9][i]=('f','fig6_viewer','Figure 5. Original input audit viewer showing the first four randomized outage cases and lead brake onset.',100)

# Caption sources are documented centrally in the named release, not as filenames in figure captions.
PAGES[2]=[(('f',el[1],'Figure 1. UML sequence of delayed commands and alternative local backup actions.',el[3]) if el[0]=='f' else el) for el in PAGES[2]]

PAGES[5][2]=('p','Table 2 reports all reference and 200 ms backup counts. In P2, Stop 3 minus Off is -4.25 percentage points [-6.75,-2.00], while Stop 4 minus Stop 3 is -10.25 points [-13.25,-7.50]. Figure 2 tests whether this conditional split persists at neighboring thresholds.')
