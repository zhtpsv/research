"""Final v6 text revision; all numerical episodes retained unchanged."""
from content_v5 import *
ABSTRACT='''A remote command can become too old to guide a moving vehicle. A backup may help, but its effect depends on brake strength, fault timing, and its action after a timeout. This study compares age limits and control architectures in a two vehicle model, without claiming to isolate early action or fresh measurements. Shared cases cover a braking leader and a leader that keeps its speed. Tests impose low delay, jitter, loss, and fixed or random outage starts. The data contain 107,200 runs based on four hundred physical cases. Collision counts and cruise distance costs are shown across the threshold sweep. Nearby limits reveal a switching boundary rather than a smooth response in the jitter profile. At the primary age limit, Remote 7 has fewer braking collisions and less cruise distance loss than Stop 7 in the loss and random outage profiles. Stop 7 avoids more collisions only under the deliberately hazard aligned fixed outage, at a cruise distance loss of about thirty five percent. This is strong nominal control versus weak nominal control with strong backup; their combination was not tested. Stratifying random outages by overlap with the full lead braking interval places most of the equal force Stop 3 benefit in the overlap group. Strong Stop 7 also helps outside that group. Full case contact scores and collision free intervention metrics complement event counts. Clock checks remain illustrative. These conditional comparisons describe the model and sampled faults, not an optimal timeout, a safety guarantee, or isolated causal effects.'''
PAGES[0][5]=('p',ABSTRACT)
# Expanded exploratory questions; clocks remain an illustration, not a robustness RQ.
PAGES[2].insert(2,('p','RQ4 asks how Remote 7 versus Stop 7 compares in collisions and cruise cost under fixed versus random outage timing, with P2 as a loss reference. This is an exploratory question, not a preregistered one.'))
# Move existing physical setup forward and code evidence into methods to balance page space.
physics=PAGES[3].pop(1)
PAGES[2].append(physics)
listing=next(e for e in PAGES[9] if e[0]=='l')
PAGES[9]=[e for e in PAGES[9] if e[0]!='l']
PAGES[3].append(listing)
# Clear abbreviations, asymmetric outcome comparison, and force-specific stratum interpretation.
for i,e in enumerate(PAGES[6]):
 if e[0]=='p' and e[1].startswith('S3/4/7 mean'):
  PAGES[6][i]=('p',e[1].replace('S3/4/7 mean Stop 3/4/7 and Sw3 means Switch 3.','Abbreviations in the collapsed rows: S3 = Stop 3, S4 = Stop 4, S7 = Stop 7, and Sw3 = Switch 3.'))
 elif e[0]=='p' and e[1].startswith('The comparison is asymmetric'):
  PAGES[6][i]=('p','Remote 7 uses nominal brake limit 7 with no backup; Stop 7 uses nominal limit 3 and backup limit 7. At 200 ms, Remote 7 has fewer collisions and less cruise loss in P2 (0 versus 13; about 0 versus 18.84 m) and P3R (5 versus 29; 0.20 versus 32.10 m). Stop 7 avoids more collisions only in deliberately hazard aligned fixed P3 (0 versus 12), at a loss of 42.31 m, or 34.9%, against approximately zero for Remote 7. These are two scenario-specific metrics, not a single measure of trip utility.')
for i,e in enumerate(PAGES[7]):
 if e[0]=='p' and e[1].startswith('Within the overlap group'):
  PAGES[7][i]=('p',e[1]+' The concentration of 51 of 53 avoided events refers to equal force Stop 3: Stop 7 also reduces nonoverlap events from 45 to 29, alongside 81 to zero in the overlap group.')
 elif e[0]=='p' and e[1].startswith('At 200 ms, Remote 7'):
  PAGES[7][i]=('p','The pooled P3R comparison differs from its overlap group: Remote 7 versus Stop 7 gives 5/29 overall, but 5/0 within overlap. At P2 190 ms they tie at zero events; at 210 ms the counts are 0/22. The primary 200 ms comparisons in Table 3 therefore describe specified profiles and thresholds, not a universal architecture ranking.')
# Numeric table gives all three strengths at requested thresholds, without adding simulations.
sweep_rows=[['Limit ms','P1 S3','P1 S4','P1 S7','P2 S3','P2 S4','P2 S7']]
for th in [100,150,200,250,400]:
 row=[str(th)]
 for p in ['P1','P2']:
  for force in [3,4,7]:
   b=ALL[(p,'brake',f'stop{force}_{th}')];c=ALL[(p,'cruise',f'stop{force}_{th}')]
   loss=ALL[(p,'cruise','off')]['distance_m']-c['distance_m']
   row.append(f"{b['events']} / {loss:.3f}")
 sweep_rows.append(row)
PAGES[8][2]=('t','Table 4. Events / cruise loss (m), 400 cases per cell; S3/S4/S7 = Stop 3/4/7',sweep_rows,[54,66,66,66,66,66,66])
PAGES[8][3]=('p','Cruise loss is Off distance minus the stopping control distance. Table 4 gives five limits for each force; Figure 4 retains the complete paired grid. In P2, Stop 3 at 100 ms avoids all observed collisions but loses 94.57 m; at 200 ms it has 95 events and loses 1.83 m. These axes use matched braking and cruise versions, not a fitted optimum or joint trip utility.')
PAGES[8][5]=('p','Thresholds below the normal command age envelope act as negative controls, not proposed operating points. With 50 ms generation and 20 ms delay, continuous age approaches 70 ms before the next delivery; Deliveries are processed before decisions, so the sampled age peaks at 60 ms on the 10 ms grid. A 50 ms threshold can therefore repeatedly engage backup even without network loss. Its low collision count can come from suppressing movement, as cruise loss makes visible.')
PAGES[8].append(('p','The P1 boundary at 200 ms is specific to strict age comparison, 10 ms quantization, processing deliveries before decisions, and recovery hysteresis. At 190 ms backup engages; at 200/210 ms it remains inactive in the main P1 trace. Inclusive comparison or altered event clocks can change this. The 30/21/27 subset is an implementation illustration, not a convergence test or evidence that 200 ms is a safe limit.'))
# Final discussion paragraph continues above limitations on the next page.
PAGES[9].insert(0,('p','In fixed P3 cruise, Stop 3 travels 116.00 m versus Switch 3 at 121.21 m: paired difference -5.21 m [-5.74,-4.71]. This contrasts stopping with continuing local following on the same maximum brake limit. It does not isolate freshness, because Switch 3 also changes update rate and delay. The cruise result avoids collision truncation but does not measure comfort or real traffic utility.'))
for i,e in enumerate(PAGES[9]):
 if e[0]=='p' and e[1].startswith('Remote 7 and Stop 7 reverse'):
  PAGES[9][i]=('p','At 200 ms, Remote 7 has fewer braking collisions and less cruise loss than Stop 7 in P2 and P3R. Stop 7 prevents more collisions only in the hazard aligned fixed P3 schedule, at a 34.9% cruise distance loss. This asymmetric tradeoff compares strong nominal control with weak nominal control plus strong backup; their untested combination remains open. Most of the equal force Stop 3 benefit lies in overlapping outages, while Stop 7 also helps without overlap. Early action and freshness remain unisolated, and no safe deployment timeout is established.')
 elif e[0]=='p' and e[1].startswith('Release MT1-v5'):
  PAGES[9][i]=('p',e[1].replace('MT1-v5','MT1-v6').replace('MT1_v5','MT1_v6').replace('Listing 1 records actual code;','Listing 1 in the methods records actual code;'))
# Use precise primary-source language for the reviewed references.
for page in PAGES:
 for i,e in enumerate(page):
  if e[0]=='p':
   page[i]=('p',e[1].replace('Takuma et al. examine predictive presentation for remote driving [18];','Takuma et al. describe a predictive display for delayed remote driving in their published abstract [18];'))
print('Abstract words',len(ABSTRACT.split()),'characters',len(ABSTRACT))
