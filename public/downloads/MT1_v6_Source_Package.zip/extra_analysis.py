from pathlib import Path
from collections import defaultdict
import csv,json
import numpy as np
ROOT=Path(__file__).resolve().parent
groups=defaultdict(list)
for row in csv.DictReader((ROOT/'episodes.csv').open(encoding='utf-8')):
    if row['config'] in ['off','stop3_50','stop3_200','stop4_200','stop7_200','local_fallback200','local3','local7','remote7']:
        groups[(row['profile'],row['scenario'],row['config'])].append(row)
for rows in groups.values():rows.sort(key=lambda r:int(r['case']))
rng=np.random.default_rng(20261020);idx=rng.integers(0,400,(10000,400))
means=[]
for p in ['P2','P3']:
    for conf in ['off','stop3_50','stop3_200','stop4_200','stop7_200','local_fallback200']:
        x=np.array([float(r['distance_m']) for r in groups[(p,'cruise',conf)]])
        b=x[idx].mean(axis=1);means.append(dict(profile=p,config=conf,mean=float(x.mean()),low=float(np.quantile(b,.025)),high=float(np.quantile(b,.975))))
extra=[]
for p,sc,a,b,metric in [('P2','brake','stop4_200','stop3_200','collision'),('P3','cruise','stop3_200','local_fallback200','distance_m')]:
    x=np.array([float(r[metric]) for r in groups[(p,sc,a)]])-np.array([float(r[metric]) for r in groups[(p,sc,b)]])
    boot=x[idx].mean(axis=1)
    extra.append(dict(profile=p,scenario=sc,a=a,b=b,metric=metric,delta=float(x.mean()),low=float(np.quantile(boot,.025)),high=float(np.quantile(boot,.975))))
(ROOT/'extra_analysis.json').write_text(json.dumps(dict(mean_intervals=means,contrasts=extra),indent=2))
print(json.dumps(extra,indent=2))
