"""Sampling and exact kinematics retained from initial MT1; no experiment runs on import."""
import math
import numpy as np
HORIZON=10.0
PERIOD=.05

def sample(n, seed):
    rng = np.random.default_rng(seed)
    return dict(v=rng.uniform(8,16,n), gap=rng.uniform(8,28,n),
                brake=rng.uniform(3,7,n), onset=rng.uniform(1.75,2.25,n))

def network(n, seed):
    rng = np.random.default_rng(seed)
    m = int(HORIZON/PERIOD)
    jitter = rng.uniform(.08,.16,(n,m))
    loss = rng.random((n,m)) < .10
    tx = np.arange(m)*PERIOD
    return {
        'P0': (np.full((n,m),.02), np.zeros((n,m),bool)),
        'P1': (jitter, np.zeros((n,m),bool)),
        'P2': (jitter.copy(), loss),
        'P3': (np.full((n,m),.02), np.broadcast_to((tx>=1.5)&(tx<3.0),(n,m)).copy())}

def advance(x,v,a,dt):
    # Exact position integral for constant acceleration, including a stop.
    moving = np.where((a<0)&(v+a*dt<0),np.divide(-v,a,out=np.zeros_like(v),where=a!=0),dt)
    moving = np.clip(moving,0,dt)
    return x+v*moving+.5*a*moving*moving, np.maximum(0,v+a*dt)

def wilson(events,n):
    z=1.95996398454; p=events/n; d=1+z*z/n
    c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [max(0,c-h),min(1,c+h)]
