from content_v4 import *
ABSTRACT=ABSTRACT.replace('whole local control','local control').replace('an ideal two vehicle model','a two vehicle model').replace('Neither remote strategy wins in all tested conditions.','Neither Remote 7 nor Stop 7 wins in all conditions.')
PAGES[0][5]=('p',ABSTRACT)
for page in PAGES:
 for i,e in enumerate(page):
  if e[0]=='p' and e[1].startswith('The P3R exposure analysis'):
   page[i]=('p','Let t_b denote the lead braking onset rounded up to the 10 ms grid, v0 the initial lead speed, and a_L the positive magnitude of lead deceleration. The untruncated lead braking interval is [t_b, t_b + v0/a_L). An outage overlaps it if the intersection has positive duration. This interval uses exogenous lead motion even if the follower has already collided. Overlap does not imply command loss during that interval or identify a causal timing mechanism. Strata are defined without selecting controller outcomes.')
  elif e[0]=='p' and e[1].startswith('Within the overlap group'):
   page[i]=('p',e[1]+' Within-stratum counts and differences are descriptive; no within-stratum contrast intervals are reported.')
# Remove redundant mini-conclusions from the methods, keeping protocol details above them.
for n,prefix in [(2,'Equal force and nonbraking'),(3,'The controller table distinguishes'),(4,'The design can identify')]:
 PAGES[n]=[e for e in PAGES[n] if not(e[0]=='p' and e[1].startswith(prefix))]
loss={p:{c:ALL[(p,'cruise','off')]['distance_m']-ALL[(p,'cruise',c)]['distance_m'] for c in ['stop7_200','remote7']} for p in ['P2','P3','P3R']}
pct=100*loss['P3']['stop7_200']/ALL[('P3','cruise','off')]['distance_m']
cost=(f"The comparison is asymmetric: Remote 7 is a nominal controller with brake limit 7 and no backup; Stop 7 uses nominal limit 3 with backup limit 7. At 200 ms, Stop 7 loses {loss['P2']['stop7_200']:.2f}/{loss['P3']['stop7_200']:.2f}/{loss['P3R']['stop7_200']:.2f} m of cruise distance relative to Off in P2/P3/P3R ({pct:.1f}% in P3); Remote 7 loses approximately zero in P2/P3 and {loss['P3R']['remote7']:.2f} m in P3R. Thus Remote 7 has much lower cruise cost in these profiles, but has 12 collisions versus Stop 7's zero in fixed P3.")
PAGES[6].append(('p',cost))
# Numeric sweep is now Results section 5.4; interpretation follows as section 6.
import csv
points={(x['profile'],int(x['threshold_ms'])):x for x in csv.DictReader((ROOT/'sweep_tradeoff.csv').open()) if x['control'].startswith('stop3_')}
sweep_rows=[['Limit ms','P1 events','P1 loss m','P2 events','P2 loss m']]
for th in [100,150,200,250,400]:
 a=points['P1',th];b=points['P2',th]
 sweep_rows.append([str(th),a['events'],f"{float(a['cruise_loss_m']):.3f}",b['events'],f"{float(b['cruise_loss_m']):.3f}"])
fig=PAGES[8][1]
PAGES[8]=[
 ('h','5.4 Threshold sweep results'),
 ('f',fig[1],fig[2],220),
 ('t','Table 4. Selected Stop 3 limits from the complete sweep; 400 cases per cell',sweep_rows,[82,86,98,86,98]),
 ('p','Loss is mean cruise distance for Off minus Stop 3; event counts use the matched braking version. Table 4 samples five limits, while Figure 4 retains the full grid. For example, P2 at 100 ms has zero collisions but loses 94.567 m; at 200 ms it has 95 collisions and loses 1.830 m. These scenario-specific axes are not a joint utility score or a fitted optimal threshold.'),
 ('h','6 Discussion'),
 ('p','The reversal between Remote 7 and Stop 7 depends on both hazard exposure and intervention cost. Stratification is descriptive: braking duration depends on speed and deceleration, and no matched random timer or state triggered emergency comparator was tested. Local alternatives jointly change measurement access, update rate, and delay; Local 3 is not an oracle and Local 7 has no proved safety guarantee. Grid switching at 200 ms should not be interpreted as a smooth response.')]
for i,e in enumerate(PAGES[9]):
 if e[0]=='p' and e[1].startswith('The point mass model'):
  PAGES[9][i]=('p',e[1]+' A strong nominal controller combined with backup was not tested. P3R uses only one sampled outage window per physical case, from seed 20261022; repeated independent outage draws are not evaluated.')
 elif e[0]=='p' and e[1].startswith('Remote 7 and Stop 7 reverse'):
  PAGES[9][i]=('p',e[1]+f" The comparison is between strong nominal control and weak nominal control with strong backup: Stop 7 loses about 18.8/42.3/32.1 m in P2/P3/P3R cruise, versus near-zero costs for Remote 7, which nevertheless has more collisions in fixed P3 (12 versus 0).")
 elif e[0]=='p' and e[1].startswith('Release MT1-v4'):
  PAGES[9][i]=('p',e[1].replace('MT1-v4','MT1-v5').replace('MT1_v4','MT1_v5'))
print('Costs',loss,'P3 percentage',pct)
