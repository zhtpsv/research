from pathlib import Path
import json,html,inspect
import numpy as np
from reportlab.graphics.shapes import Drawing,Rect,Line,String,Polygon,Circle
from reportlab.graphics import renderPDF,renderSVG
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import pypdfium2 as pdfium
import experiment
ROOT=Path(__file__).resolve().parent;A=ROOT/'figures';A.mkdir(exist_ok=True)
pdfmetrics.registerFont(TTFont('Times','C:/Windows/Fonts/times.ttf'))
R=json.loads((ROOT/'results.json').read_text());SUP=json.loads((ROOT/'supplement_results.json').read_text());S={(r['profile'],r['scenario'],r['config']):r for r in R['summary']+SUP['summary']}
EX=json.loads((ROOT/'extra_analysis.json').read_text());CI={(x['profile'],x['config']):x for x in EX['mean_intervals']}
INK=colors.HexColor('#203B4C');BLUE=colors.HexColor('#357492');ORANGE=colors.HexColor('#BB6C32');GRAY=colors.HexColor('#D5DDE2')
def text(d,x,y,s,size=11,anchor='start',col=INK):d.add(String(x,y,str(s),fontName='Times',fontSize=size,textAnchor=anchor,fillColor=col))
def line(d,x,y,X,Y,col=INK):d.add(Line(x,y,X,Y,strokeColor=col,strokeWidth=.7))
def arrow(d,x,y,X,Y,label):
    line(d,x,y,X,Y);direction=1 if X>x else -1
    d.add(Polygon([X,Y,X-direction*5,Y+3,X-direction*5,Y-3],fillColor=INK,strokeColor=None));text(d,(x+X)/2,y+6,label,anchor='middle')
def save(d,name):
    renderSVG.drawToFile(d,str(A/(name+'.svg')));renderPDF.drawToFile(d,str(A/(name+'.pdf')))
    p=pdfium.PdfDocument(str(A/(name+'.pdf')));p[0].render(scale=300/72).to_pil().save(A/(name+'.png'),dpi=(300,300));p.close()

d=Drawing(480,250)
for x,label in [(55,'Vehicle'),(185,'Remote control'),(315,'Channel'),(425,'Local arbiter')]:
    d.add(Rect(x-49,212,98,26,strokeColor=INK,fillColor=colors.white));text(d,x,222,label,anchor='middle')
    d.add(Line(x,210,x,15,strokeColor=INK,strokeDashArray=[3,3],strokeWidth=.6))
arrow(d,55,190,185,190,'state timestamp s')
arrow(d,185,155,315,155,'command and s')
arrow(d,315,120,425,120,'delay / loss')
d.add(Rect(5,25,470,77,strokeColor=INK,fillColor=None));text(d,12,87,'alt [command age > threshold]')
arrow(d,425,67,55,67,'stop at chosen force OR local control')
text(d,12,46,'else [fresh remote mode]');arrow(d,425,29,55,29,'hold newest accepted command')
save(d,'fig1_sequence')

d=Drawing(480,280)
forces=[(3,BLUE),(4,ORANGE),(7,colors.HexColor('#697A63'))]
for i,(f,col) in enumerate(forces):
    d.add(Rect(100+i*110,256,8,8,fillColor=col,strokeColor=None));text(d,113+i*110,256,str(f)+' m/s2')
for pi,p in enumerate(['P1','P2']):
    x0=45+pi*236;y0=48;w=184;h=171
    text(d,x0,235,p+' | lead brakes')
    for tick in [0,10,20,30,35]:
        y=y0+tick/35*h;line(d,x0,y,x0+w,y,GRAY)
        if pi==0:text(d,x0-6,y-3,tick,anchor='end')
    for f,col in forces:
        points=[]
        for j,th in enumerate([190,200,210]):
            r=S[(p,'brake',f'stop{f}_{th}')];x=x0+14+j*78+({3:-4,4:0,7:4}[f]);y=y0+r['rate']*100/35*h
            points.append((x,y));d.add(Circle(x,y,2.3,fillColor=col,strokeColor=None))
            lo,hi=r['wilson'];line(d,x,y0+lo*100/35*h,x,y0+hi*100/35*h,col)
            line(d,x-3,y0+hi*100/35*h,x+3,y0+hi*100/35*h,col)
    off=S[(p,'brake','off')]['rate']*100
    line(d,x0,y0+off/35*h,x0+w,y0+off/35*h,colors.black)
    text(d,x0+w,y0+off/35*h+5,'Off',9,anchor='end',col=colors.black)
    for j,th in enumerate([190,200,210]):text(d,x0+14+j*78,y0-16,str(th),anchor='middle')
text(d,5,228,'%')
text(d,240,10,'x: age threshold (ms); y: collision proportion (%); error bars: 95% Wilson intervals',anchor='middle')
save(d,'fig2_boundary')

d=Drawing(480,265)
confs=['off','stop3_200','stop4_200','stop7_200','local_fallback200','remote7']
short=['Off','S3','S4','S7','Sw3','R7']
for pi,p in enumerate(['P3','P3R']):
    x0=43+pi*236;y0=51;h=164;w=189
    text(d,x0,236,'Fixed hazard aligned' if p=='P3' else 'Random outage start')
    for tick in [0,25,50,75,100]:
        y=y0+tick/100*h;line(d,x0,y,x0+w,y,GRAY)
        if pi==0:text(d,x0-6,y-3,tick,anchor='end')
    for j,conf in enumerate(confs):
        r=S[(p,'brake',conf)];x=x0+4+j*31
        d.add(Rect(x,y0,19,r['rate']*h,fillColor=BLUE,strokeColor=None))
        lo,hi=r['wilson'];line(d,x+9,y0+lo*h,x+9,y0+hi*h)
        line(d,x+6,y0+hi*h,x+12,y0+hi*h)
        text(d,x+9,y0-17,short[j],10,anchor='middle')
text(d,5,225,'%')
text(d,240,13,'Collision proportion (%), 95% Wilson intervals; backup timeout 200 ms',anchor='middle')
save(d,'fig3_outages')

# Screenshots document an actual code excerpt and an original data viewer.
code=inspect.getsource(experiment.nominal)+'\n'+inspect.getsource(experiment.advance)
code='\n'.join(code.splitlines()[:10])
(A/'implementation.html').write_text('<!doctype html><meta charset="utf-8"><style>body{margin:24px;background:white;color:#173547;font:22px Consolas}h1{font:24px Arial}pre{white-space:pre-wrap;line-height:1.35}</style><h1>Following control and exact stopping integration</h1><pre>'+html.escape(code)+'</pre>',encoding='utf-8')
import csv
cases=list(csv.DictReader((ROOT/'cases.csv').open()))
outages=list(csv.DictReader((ROOT/'outage_manifest.csv').open()))
rows=''.join('<tr><td>'+r['case']+'</td><td>'+f"{float(r['start_s']):.3f}"+'</td><td>'+f"{float(r['end_s']):.3f}"+'</td><td>'+f"{np.ceil(float(cases[int(r['case'])]['onset'])/.01-1e-9)*.01:.2f}"+'</td><td>'+('Yes' if r['contains_brake_onset']=='1' else 'No')+'</td></tr>' for r in outages[:4])
(A/'viewer.html').write_text('<!doctype html><meta charset="utf-8"><style>body{margin:24px;color:#173547;background:white;font:23px Arial}h1{font-size:28px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd5da;padding:12px}th{background:#eef3f5}</style><h1>Random outage input viewer · first four cases</h1><table><tr><th>Case</th><th>Start s</th><th>End s</th><th>Lead onset s</th><th>Contains onset</th></tr>'+rows+'</table>',encoding='utf-8')
(A/'sequence.puml').write_text('@startuml\nparticipant Vehicle\nparticipant Remote\nparticipant Channel\nparticipant Arbiter\nVehicle -> Remote: state and timestamp\nRemote -> Channel: command and timestamp\nChannel -> Arbiter: delivery or loss\nalt age > threshold\nArbiter -> Vehicle: stop or local controller\nelse fresh remote mode\nArbiter -> Vehicle: hold newest accepted command\nend\n@enduml',encoding='utf-8')
print('Created revised original figures')
