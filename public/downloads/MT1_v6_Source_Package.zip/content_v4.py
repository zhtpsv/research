"""V4 interpretation-only revision; no new simulation episodes."""
from content_v3 import *
ABSTRACT='''A remote command can become too old to guide a moving vehicle. A local backup may help, but its effect depends on brake strength and on what it does after a timeout. This study compares age limits, brake strength, and whole local control alternatives in an ideal two vehicle model. It does not isolate early action or fresh measurements. Shared cases cover a braking leader and a leader that keeps its speed. Tests impose low delay, jitter, loss, and fixed or random outage starts. Data contain 107,200 runs based on four hundred physical cases. Collision counts and cruise distance costs are reported across the available threshold sweep. Nearby limits expose a switching boundary in the jitter profile. In the loss profile, the extra benefit from stronger brakes varies less than the equal force benefit. The ranking of strong nominal remote control and strong backup reverses across outage schedules and can tie at a lower limit. Neither remote strategy wins in all tested conditions. The random outage overlaps the full lead braking interval in 186 cases, compared with only 66 windows containing its onset. Stratified counts show that most of the equal force benefit lies in the overlap group. A contact measure averaged over all cases complements counts without selecting only vehicles that collide. Backup time and entries are reported in cruise cases to avoid collision truncation. Clock checks remain illustrative. The findings describe conditional tradeoffs in this model, not independent causal effects, an optimal timeout, or a road safety guarantee.'''
PAGES[0][5]=('p',ABSTRACT)
# Explicit stratification definition and exhaustive data availability.
PAGES[4].insert(3,('p','The P3R exposure analysis uses the untruncated lead braking interval [ceil(onset/0.01)*0.01, start + initial speed/deceleration). An outage overlaps it when the interval intersection has positive duration. This definition uses exogenous lead motion even if the follower has already collided. It does not imply a command loss during that interval or identify a causal timing mechanism. Counts are stratified descriptively, without selecting cases by controller outcomes.'))
PAGES[5][4]=('p','Fixed P3 gives 4 events with Stop 3 versus 303 with Off: -74.75 percentage points [-78.75,-70.50]. This equal force reduction occurs under a hazard aligned schedule and does not identify a benefit of age triggering over other early stopping rules.')
PAGES[5][2]=('p','Table 2 reports all references and 200 ms backups. In P2, Stop 3 minus Off is -4.25 percentage points [-6.75,-2.00]; Stop 4 minus Stop 3 is -10.25 points [-13.25,-7.50]. Figure 2 includes Off and leaves adjacent thresholds unconnected because a switching boundary need not be smooth.')
for i,e in enumerate(PAGES[5]):
 if e[0]=='f':PAGES[5][i]=('f','fig2_boundary','Figure 2. Neighboring thresholds with 95% Wilson bars and Off reference. Marker offsets separate overlapping forces within each threshold; no interpolation is implied.',170)
 elif e[0]=='p' and e[1].startswith('At P1, forces'):
  PAGES[5][i]=('p','In P1, forces 3/4/7 give 82/35/3 events at 190 ms, but 112/112/112 at 200 and 210 ms, where backup is inactive. In P2, counts are 55/7/0, 95/54/13, and 98/65/22. Stop 3 minus Off equals -14.25/-4.25/-3.50 percentage points; extra reductions for force 3 to 4 are 12.00/10.25/8.25 points, with paired 95% intervals [9.00,15.25], [7.50,13.25], [5.75,11.00]. The equal force share of the total Off-to-Stop 7 reduction is 50.9%/17.2%/15.6%. These descriptive ratios are not causal components; the brake increment varies less than the equal force contrast.')
# Compress inactive duplicate rows; add missing architecture references and collision-free intervention metrics.
rows=[['Profile / control','Events','J m2/s2','Cruise m','Backup s*','Entries*']]
labels={'off':'Off','stop3_200':'Stop 3','stop4_200':'Stop 4','stop7_200':'Stop 7','local_fallback200':'Switch 3','remote7':'Remote 7'}
def addrow(p,conf,label=None):
 b=ALL[(p,'brake',conf)];c=ALL[(p,'cruise',conf)]
 rows.append([label or p+' / '+labels.get(conf,conf),str(b['events']),f"{b['impact_squared']:.3f}",f"{c['distance_m']:.2f}",f"{c['fallback_s']:.3f}",f"{c['entries']:.2f}"])
for p in ['P0','P1']:
 addrow(p,'off',p+' / Off, S3/4/7, Sw3');addrow(p,'remote7')
for conf in ['local3','local7']:addrow('P0',conf,'All / Local '+conf[-1])
for p in ['P2','P3','P3R']:
 for conf in labels:addrow(p,conf)
PAGES[6]=[
 ('h','5.2 Contact and collision free intervention outcomes'),
 ('p','Table 3 uses all 400 braking cases per cell for events and J, with zero contact score for noncollisions. Cruise distance and the starred backup time and entry count use 400 nonbraking cases, all without collisions, so intervention metrics are not truncated by a collision. P0/P1 inactive backup rows are collapsed. Local references are identical across profiles and shown once; no new P3R local runs are counted.'),
 ('t','Table 3. Main 200 ms outcomes and complete architecture references',rows,[164,39,61,61,67,58]),
 ('p','S3/4/7 mean Stop 3/4/7 and Sw3 means Switch 3. Remote and always local references have no backup activation. In P2, J is 5.098 for Off and 3.922 for Stop 3: paired difference -1.176 m2/s2 [-1.572,-0.811]. This descriptive score combines contact frequency and speed; it is not injury risk.')]
PAGES[7]=[
 ('h','5.3 Outage exposure and conditional rankings'),
 ('p','Of 400 random P3R outages, 186 overlap the full untruncated lead braking interval and 214 do not; 66 contain onset. Figure 3 stratifies by interval overlap. These strata describe exposure to lead braking, not a randomized comparison between strata; braking duration also depends on the sampled speed and deceleration.'),
 ('f','fig3_strata','Figure 3. P3R counts and proportions by braking interval overlap. S3/4/7 denote stop force, Sw3 is Switch 3, R7 is Remote 7; backups use 200 ms. Each panel has its own stated denominator.',185),
 ('p','Within the overlap group, Off/Stop 3 events are 81/30 of 186; without overlap they are 45/43 of 214. Matched P0 Off counts are 41 and 47, respectively: P3R Off excess is +40 and -2. Thus the net excess of 38 is concentrated in the overlap stratum, and the Stop 3 reduction of 53 decomposes into 51 and 2 events. This is descriptive stratification, not evidence that overlap alone causes every excess collision. Nonoverlap can still allow carryover from an earlier outage.'),
 ('p','At 200 ms, Remote 7 versus Stop 7 gives 0/13 events in P2, 12/0 in fixed P3, and 5/29 in P3R. P2 gives a 0/0 tie at 190 ms and 0/22 at 210 ms. Ranking therefore depends on profile and threshold, and even the P3R overlap stratum reverses the pooled comparison (5/0 versus pooled 5/29). No general superiority follows.'),
 ('p','Overall P3R Stop 3 minus Off remains -13.25 percentage points [-16.75,-10.00], with J difference -7.698 m2/s2 [-10.151,-5.464]. The illustrative P1 100-case subset gives 30/21/27 events for random-phase strict, random-phase inclusive, and the joint 5 ms implementation variant. It establishes no clock robustness.')]
PAGES[8]=[
 ('h','6 Discussion and the complete threshold tradeoff'),
 ('f','fig4_sweep','Figure 4. Collision proportion versus cruise distance loss relative to Off in P1/P2. Every available paired threshold is retained: 22 for Stop 3 (50 to 250 ms by 10 ms, plus 400), six for Stop 4/7 (50,100,150,200,250,400). Reference points include Off and Local 3; Remote 7 and Local 7 overlap near zero loss and zero events. The new force 4/7 neighbor tests have braking data only and are therefore excluded from this paired plot.',270),
 ('p','The 25,600 dense sweep runs remain part of the results, rather than merely the methods. Low thresholds can avoid collisions by stopping much of the time, at a large cruise distance cost. Cruise and braking outcomes come from matched but different scenario versions; the axes are not a joint utility score or a fitted Pareto frontier. A lower collision count alone does not select a deployment threshold. The exact coordinates are in the named source release.'),
 ('p','Controller rankings reverse with the fault schedule. The fixed P3 aligns every onset with outage; random P3R dilutes exposure and mixes overlapping and nonoverlapping cases. The stratification explains much of the pooled contrast but does not isolate early action from the chosen backup law. No matched random timer or state triggered emergency comparator was tested.'),
 ('p','Local controls are whole alternatives with ideal current measurements, 10 ms updates, and no network delay. Their outcomes cannot be attributed to freshness alone. Local 3 has 77 events, not 77 physically unavoidable cases. Local 7 has zero observed events, not a formal safety certificate. The 200 ms P1 boundary depends on strict comparison, grid clocks, delivery order, and recovery; three adjacent points do not establish a smooth response.')]
# Narrow conclusions; replace the low-information input screenshot with exposure distribution.
for i,e in enumerate(PAGES[9]):
 if e[0]=='p' and (e[1].startswith('The targeted extensions') or e[1].startswith('Equal force')):
  PAGES[9][i]=('p','Remote 7 and Stop 7 reverse ranking across profiles and thresholds. The full sweep makes the collision versus cruise cost visible; the P3R strata locate the pooled equal force benefit mainly in windows overlapping lead braking. Force, switching, and exposure should be reported together. Early action and freshness remain unisolated, clock checks illustrative, and these results do not establish a safe deployment timeout.')
 elif e[0]=='p' and e[1].startswith('Data release'):
  PAGES[9][i]=('p','Release MT1-v4-20261018 is supplied as MT1_v4_Source_Package.zip with SHA256.json file checksums. It retains all 107,200 main runs and adds descriptive reanalysis, not new simulations. Listing 1 records actual code; Figure 5 shows the generated outage exposure rather than selected example cases.')
 elif e[0]=='f' and e[1]=='fig5_code':PAGES[9][i]=('f','fig5_code','Listing 1. Actual following law and exact within step stopping integration.',105)
 elif e[0]=='f' and e[1]=='fig6_viewer':PAGES[9][i]=('f','fig5_exposure','Figure 5. Generated random outage starts and exposure counts. Equal width histogram bins describe this synthetic draw, not a fitted radio failure distribution.',100)
for page in PAGES:
 for i,e in enumerate(page):
  if e[0]=='p':page[i]=('p',e[1].replace('Section conclusion. ',''))
''

# Editable monospace listing, preserving the actual source content.
import inspect, textwrap
import experiment
code=inspect.getsource(experiment.nominal)+'\n'+inspect.getsource(experiment.advance)
code='\n'.join('\n'.join(textwrap.wrap(line, width=92, subsequent_indent='    ',replace_whitespace=False,drop_whitespace=False)) if len(line)>92 else line for line in code.splitlines())
for i,e in enumerate(PAGES[9]):
 if e[0]=='f' and e[1]=='fig5_code':PAGES[9][i]=('l',code,'Listing 1. Actual following law and exact within step stopping integration; long lines wrap.')
